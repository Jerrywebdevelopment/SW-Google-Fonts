﻿=== SW Google Fonts ===
Contributors: Salvador
Tags: Google fonts, fonts, font, type, free fonts, typography, theme, admin, plugin, css, design, plugin, template, page, posts, links, Google
Requires at least: 2.0.2
Tested up to: 4.4.2
Stable tag: trunk
License: GPLv2 or later

The SW Google Fonts plugin allows you to easily add fonts from the Google Font Directory to your Wordpress theme. 

== Description ==

The SW Google Fonts plugin allows you to easily add fonts from the Google Font Directory to your Wordpress theme. 



1. Download plugin zip file to your computer and extract in a folder
1. Upload `sw-google-fonts` folder to the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress

== Frequently Asked Questions ==

== Screenshots ==


== Changelog ==

